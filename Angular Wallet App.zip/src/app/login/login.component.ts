import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';
import { Customer } from '../Customer';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router :Router,private customerservice:CustomerService) { }

  username='';
  password=null;
  
  customers:Customer[];

  customer:Customer;
  ngOnInit() {
    this.customerservice.getCustomerList().subscribe( (data:any[]) => {
      this.customers = data;
      console.log(this.customers);
    });
  }
  checkLogin()
  {
  this.customer=this.customers.find(x=>x.name ==this.username);
  if(this.username=='admin' && this.password=='1234')
    {
           this.router.navigate['List'];
    }
  
  else
  {

    if(this.customer.customerId==this.password)
    {
        console.log("Login Succesfull");
       
        this.router.navigate(['UserOperation',this.customer.accountNumber]);
       // this.customerservice.Setter(this.customer);
    }
    else{
      alert("Wrong Password");
    }



  }
}

}
