import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-show-balance',
  templateUrl: './show-balance.component.html',
  styleUrls: ['./show-balance.component.css']
})
export class ShowBalanceComponent implements OnInit {

  accountNumber;
  Balance;
  status="Available Balance : ";
  submitted=false;
  constructor(private http:HttpClient,private router:Router,
    private customerService:CustomerService) { }

  ngOnInit() {

  }
  showBalance()
  {
    this.customerService.showBalance(this.accountNumber).subscribe
    (
      data=>{
        console.log(data)
        this.Balance=data;
      },
      error=>{
        console.log(error);
        alert("Customer Not Found for id "+this.accountNumber);
      }
    );
    this.submitted=true;
  }
  Onsubmit()
  {
      this.showBalance();
     
  }
  back()
  {
    this.router.navigate(['UserOperation',this.accountNumber]);
  }
}
