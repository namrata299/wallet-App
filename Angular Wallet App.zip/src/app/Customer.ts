export class Customer {
    name: string;
    customerId: number;
    accountNumber: number;
    accountNumber1: number;
    address: string;
    emailId: string;
    balance: number;
    contactNumber: number;
    amount:number;
}
