export class Transaction{
    accountNumber:number;
    transID:String;
    details:String;
    amount:number;
    trans_dateTime:String;
    senderAccNo:number;
    receiverAccNo:number;
    nBalance:number;
}