import { Injectable } from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient} from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class TransactionService {

  private baseUrl='http://localhost:9092/bank/customers/transactions';
  constructor(private http:HttpClient) { }
  


  getTransaction(accNumber:number):Observable<any>{
    return this.http.get( `${this.baseUrl}/${accNumber}`);
  }
  getTransactionList():Observable<any>{
    
    return this.http.get(`${this.baseUrl}`);
  }

}
