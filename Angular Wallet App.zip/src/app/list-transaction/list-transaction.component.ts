import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { TransactionService } from '../transaction.service';
import { error } from 'protractor';
import { Transaction } from '../Transaction';

@Component({
  selector: 'app-list-transaction',
  templateUrl: './list-transaction.component.html',
  styleUrls: ['./list-transaction.component.css']
})
export class ListTransactionComponent implements OnInit {
 
  transactions:Transaction[];
  constructor(private http:HttpClient,
    private router:Router,private transactionService:TransactionService) { }

  
  ngOnInit() {
    this.transactionService.getTransactionList().subscribe(
      (data:any[])=>{
        this.transactions=data;
        console.log(this.transactions);
      }
    )

  }

}
