import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateAccountComponent } from './create-account/create-account.component';
import {DepositComponent} from './deposit/deposit.component';
import {WithdrawComponent} from './withdraw/withdraw.component';
import {FundTransferComponent} from './fund-transfer/fund-transfer.component';
import { AccountListComponent } from './account-list/account-list.component';
import { UpdateAccountComponent } from './update-account/update-account.component';
import { DetailsComponent } from './details/details.component';
import { UserOperationComponent } from './user-operation/user-operation.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { AdminComponent } from './admin/admin.component';
import { ListTransactionComponent } from './list-transaction/list-transaction.component';
import { ShowtransactionComponent } from './showtransaction/showtransaction.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';

const routes: Routes = [
  { path: '', redirectTo: 'create', pathMatch: 'full' },
  { path: 'create', component: CreateAccountComponent },
  { path: 'deposit/:accountNumber/:amount', component: DepositComponent },
  { path: 'withdraw/:accountNumber/:amount', component: WithdrawComponent },
  { path: 'fund-transfer/:accountNumber/:accountNumber/:amount', component: FundTransferComponent },
  {path:'List',component:AccountListComponent},
  {path:'update/:accountNumber',component:UpdateAccountComponent},
  {path:'details/:accountNumber',component:DetailsComponent},
  {path:'UserOperation/:accountNumber',component:UserOperationComponent},
  {path:'ShowBalance',component:ShowBalanceComponent},
  {path:'admin',component:AdminComponent},
  {path:'TransactionList',component:ListTransactionComponent},
  {path:'ShowTransactionSummary/:accountNumber',component:ShowtransactionComponent},
  {path:'Login',component:LoginComponent},
  {path:'Logout',component:LogoutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
