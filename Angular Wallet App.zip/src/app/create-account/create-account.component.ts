import { Component, OnInit } from '@angular/core';
import { Customer } from "../Customer";
import { CustomerService } from '../customer.service';
import { Route } from '@angular/compiler/src/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent implements OnInit {
  customer:Customer=new Customer();
  
  submitted=false;
  constructor(private customerService:CustomerService,
    private router:Router) { }

 
  ngOnInit() {
   
  }

  save(){
    this.customerService.createAccount(this.customer)
    .subscribe(data=>console.log(data),error=>console.log(error));
  
    alert("Account Created Successfully!!");
    this.customer=new Customer();
  
  }
  gotoList() {
    this.router.navigate(['/List']);
  }
  onSubmit()
  {
   // this.submitted=true;
    this.save();
  }
}
