import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor() { }

  authenticate(username, password) {
    if (username === "admin" && password === "admin") {
      sessionStorage.setItem('username', username)
      localStorage.setItem('username', username)
      console.log("In autheticate");
      console.log(username);
      return true;
    } else {
      return false;
    }
  }

  isUserLoggedIn() {
    if(localStorage.getItem('username'))
    {
      return true;
    }
    return false;
    
    /*let user = sessionStorage.getItem('username')
    console.log(!(user === null))
    console.log(!(user === null));
    return !(user === null)
*/
  }
  getToken()
    {
      const admin=localStorage.getItem('username');
      return admin;
    }

  logOut() {
    sessionStorage.removeItem('username')
  }
}