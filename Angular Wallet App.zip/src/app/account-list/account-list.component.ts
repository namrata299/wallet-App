import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Observable } from 'rxjs';
import { Customer } from '../Customer';
import { Router } from '@angular/router';
import { Transaction } from '../Transaction';
import { AuthenticationService } from '../authentication.service';

@Component({
  selector: 'app-account-list',
  templateUrl: './account-list.component.html',
  styleUrls: ['./account-list.component.css']
})
export class AccountListComponent implements OnInit {

  customers:Customer[];
 
  constructor(private custService:CustomerService,
    private router:Router,private loginservice:AuthenticationService) { }

  ngOnInit() {
    this.getData();
  }
  getData() {
    if(this.loginservice.isUserLoggedIn())
    {

    
    this.custService.getCustomerList().subscribe( (data:any[]) => {
      this.customers = data;
      console.log(this.customers);
    });
  }
  }

  deleteCustomer(id: number) {
    this.custService.deleteCustomer(id)
      .subscribe(
        data => {
          console.log(data);
          this.getData();
        },
        error => console.log(error));
        alert("Account Deleted with "+id);
  }
  updateCustomer(accountNumber: number){
    this.router.navigate(['update', accountNumber]);
  }
  Customerdetails(accountNumber:number)
  {
   

   
    this.router.navigate(['details',accountNumber]);
  
  }
  transactionDetails(accountNumber:number)
  {
    this.router.navigate(['ShowTransactionSummary',accountNumber]);
  }
}
