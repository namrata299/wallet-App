import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable, throwError} from 'rxjs';
import { catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  

  private baseUrl='http://localhost:9092/bank/customers';
  constructor(private http:HttpClient) { }
  
  createAccount(Customer:Object):Observable<Object>
  {
    return this.http.post(`${this.baseUrl}`,Customer).pipe(
      catchError(this.handleError)
    );
  }
 

  getCustomerList():Observable<any>{
    //return this.http.get(this.baseUrl);
    return this.http.get(`${this.baseUrl}`).pipe(
      catchError(this.handleError)
    );
  }

  deleteCustomer(accountNumber:number):Observable<any>{
    return  this.http.delete(`${this.baseUrl}/${accountNumber}`).pipe(
      catchError(this.handleError)
    );
  }
  getCustomer(accNo: number) :Observable<any> {
    return this.http.get(`${this.baseUrl}/${accNo}`).pipe(
      catchError(this.handleError)
    );
  }
  updateCustomer(accNo: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/${accNo}`, value);
  }
  deposit(accNo:number,amount:number,value: any ):Observable<Object>
    {
    return this.http.put(`${this.baseUrl}/depositmoney/${accNo}/${amount}`,value).pipe(
      catchError(this.handleError)
    );
    }
  
  withdraw(accNo:number,amount:number,value: any ):Observable<Object>
    {
    return this.http.put(`${this.baseUrl}/withdrawmoney/${accNo}/${amount}`,value).pipe(
      catchError(this.handleError)
    );
    }

  fundTransfer(accNo1:number,accNo2:number,amount:number,value:any):Observable<Object>
  {
    return this.http.put(`${this.baseUrl}/fundtransfer/${accNo1}/${accNo2}/${amount}`,value).pipe(
      catchError(this.handleError)
    );
  }

  showBalance(accNo:number):Observable<any>
  {
    return this.http.get(`${this.baseUrl}/showBalance/${accNo}`).pipe(
      catchError(this.handleError)
    );
  }

  handleError(error) {
    let errorMessage='';
    if(error.error instanceof ErrorEvent)
    {
        errorMessage=`Error:${error.error.errorMessage}`;
        console.log("Client Side");
    }
    else{

      errorMessage=`Error:${error.error.errorMessage}`;
      console.log("Server SIde");

    }
    console.log(error.error.errorMessage);
    return throwError(error);
  }

  }

    
  
