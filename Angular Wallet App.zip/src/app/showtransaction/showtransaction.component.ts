import { Component, OnInit } from '@angular/core';
import { TransactionService } from '../transaction.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Route } from '@angular/compiler/src/core';

@Component({
  selector: 'app-showtransaction',
  templateUrl: './showtransaction.component.html',
  styleUrls: ['./showtransaction.component.css']
})
export class ShowtransactionComponent implements OnInit {
  accountNumber: number;
 transactions;
  constructor(private transactionService:TransactionService,
    private router:Router,
    private route:ActivatedRoute) { }

  ngOnInit() {
    this.accountNumber=this.route.snapshot.params['accountNumber']
    this.transactionService.getTransaction(this.accountNumber).
      subscribe(
      
        data=>
        {console.log(data);
        this.transactions=data;

        },
        error=>console.log(error)
      )
  }
  back()
  {
    this.router.navigate(['UserOperation',this.accountNumber]);
  }
}
