import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowtransactionComponent } from './showtransaction.component';

describe('ShowtransactionComponent', () => {
  let component: ShowtransactionComponent;
  let fixture: ComponentFixture<ShowtransactionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowtransactionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowtransactionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
