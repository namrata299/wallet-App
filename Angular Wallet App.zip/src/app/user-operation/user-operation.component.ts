import { Component, OnInit } from '@angular/core';
import { Customer } from '../Customer';
import { CustomerService } from '../customer.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-user-operation',
  templateUrl: './user-operation.component.html',
  styleUrls: ['./user-operation.component.css']
})
export class UserOperationComponent implements OnInit {
  accountNumber: number;
  customer: Customer;
  amount:number;
  show=false;
  constructor(private route: ActivatedRoute,private router: Router,
    private customerService: CustomerService) { }

  ngOnInit() {
   // this.customer = new Customer();

    this.accountNumber = this.route.snapshot.params['accountNumber'];
 
    this.customerService.getCustomer(this.accountNumber)
      .subscribe(data => {
        console.log(data)
        this.customer = data;
      }, error => console.log(error));
      this.show=true;
     
  }
 /* withdraw()
  {
    this.router.navigate(['withdraw',this.accountNumber,'']);
  }
  deposit()
  {
    this.router.navigate(['deposit',this.accountNumber,'']);
  }
  fundtransfer(){
    this.router.navigate(['fund-transfer','','','']);
  }
  check(){
    this.router.navigate(['ShowBalance']);
  }*/
}
