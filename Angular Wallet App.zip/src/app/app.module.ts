import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import {FormsModule} from '@angular/forms';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { AccountListComponent } from './account-list/account-list.component';
import { UpdateAccountComponent } from './update-account/update-account.component';
import { DetailsComponent } from './details/details.component';
import { UserOperationComponent } from './user-operation/user-operation.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { AdminComponent } from './admin/admin.component';
import { ListTransactionComponent } from './list-transaction/list-transaction.component';
import { ShowtransactionComponent } from './showtransaction/showtransaction.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
@NgModule({
  declarations: [
    AppComponent,
    CreateAccountComponent,
    DepositComponent,
    WithdrawComponent,
    FundTransferComponent,
    AccountListComponent,
    UpdateAccountComponent,
    DetailsComponent,
    UserOperationComponent,
    ShowBalanceComponent,
    AdminComponent,
    ListTransactionComponent,
    ShowtransactionComponent,
    LoginComponent,
    LogoutComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
