import { Component, OnInit } from '@angular/core';
import { Customer } from '../Customer';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CustomerService } from '../customer.service';
import { Transaction } from '../Transaction';
import {switchMap} from 'rxjs/operators';
import { TransactionService } from '../transaction.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {

  customer:Customer;
  transaction: Transaction = new Transaction();

  amount:number;
  accountNumber:number;
  moneydeposited=false;
  customerFound=false;
  flag=false;
  constructor(private route:ActivatedRoute,private http:HttpClient,
    private router:Router,private custservice:CustomerService,
    private trnsactionService:TransactionService) { }
  ngOnInit() {
    this.customer=new Customer();
    this.accountNumber=this.route.snapshot.params['accountNumber'];
  }

  getCustomer()
  {
    this.custservice.getCustomer(this.accountNumber).subscribe(
      data=>{
        console.log(data);
        this.customer=data;
      },
      error=>{
        console.log(error);
        alert("Customer Not Found for ID "+this.accountNumber);
      }
    );
    this.customerFound=true;
    this.deposit(this.accountNumber,this.amount);  
  }
  
   deposit(accountNumber,amount)
  {
    if(amount>0)
    {

    
   /* this.custservice.getCustomer(this.accountNumber).subscribe(
      data=>{
        console.log(data);
        this.customer=data;
      },
      error=>{
        console.log(error);
        alert("Customer Not Found for ID "+accountNumber);
      }
    );*/
    


    this.custservice.deposit(this.accountNumber,this.amount,this.customer)
    .subscribe(data=>console.log(data),
    error=>
    {
      alert(console.log(error));
      alert("Can't Deposit Money");
    }
    );
    this.moneydeposited=true;


   
    if( this.customerFound=true)
  { 
    
    alert("Money Deposited in "+this.accountNumber);
    this.router.navigate(['ShowTransactionSummary',accountNumber]);
  }
    
  
  }else
  {
    alert("Please,enter valid amount");
  }
  }
 
  onSubmit() {
   this.getCustomer();
  }
  

}
