import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../authentication.service';
import { admin } from 'src/admin';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
admin1:admin=new admin;
username;
password;
invalidLogin=false;
  constructor(private router :Router, private loginservice: AuthenticationService) { }
 
  ngOnInit() {
   
    
  }
 /* loginCheck()
  {
    if(this.username=='admin' && this.password=='admin'){
      this.router.navigate(['/List']);
    }
    else{
      alert("Invalid Username or Password");
    }
  }
  onSubmit(){
    this.loginCheck();
  }*/

  checkLogin() {
    if (this.loginservice.authenticate(this.admin1.username , this.admin1.password)) 
    {
      
      this.invalidLogin = false
      if(this.loginservice.isUserLoggedIn())
      {
        this.loginservice.getToken();
        this.router.navigate(['List'])
      }
    }
     else
      this.invalidLogin = true
  }
 
 
}
