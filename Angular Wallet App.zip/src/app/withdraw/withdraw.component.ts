import { Component, OnInit } from '@angular/core';
import { Customer } from '../Customer';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CustomerService } from '../customer.service';
import { Transaction } from '../Transaction';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  customer:Customer;
   transaction: Transaction = new Transaction();

  amount:number;
  accountNumber:number;
  moneywithdrawn=false;
  constructor(private route:ActivatedRoute,private http:HttpClient,
    private router:Router,private custservice:CustomerService) { }
  ngOnInit() {
    this.customer=new Customer();
    this.accountNumber=this.route.snapshot.params['accountNumber'];
  }
  withdraw(accountNumber,amount)
  {
    if(amount>0)
    {
      
    
    this.custservice.getCustomer(this.accountNumber).subscribe(
      data=>{
        console.log(data);
        this.customer=data;
      },
      error=>{
       alert( console.log(error));
       alert("Not enough balance");
      }
    );
    this.custservice.withdraw(this.accountNumber,this.amount,this.customer)
    .subscribe(data=>console.log(data),
    error=>console.log(error)
    );
    alert("Money withdrawn from "+this.accountNumber);
    this. moneywithdrawn=true;

    
    if(this.moneywithdrawn=true)
  {
    this.router.navigate(['ShowTransactionSummary',this.accountNumber]);
  }

  }
    else
    {
        alert("Please,Enter Valid amount");
    }
  }

  
  onSubmit() {
   this.withdraw(this.accountNumber,this.amount);  
  }
back()
{
  this.router.navigate(['UserOperation',this.accountNumber]);
}
}
