import { Component, OnInit } from '@angular/core';
import { Customer } from '../Customer';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

 
  accountNumber: number;
  customer: Customer;
  amount:number;
  constructor(private route: ActivatedRoute,private router: Router,
    private customerService: CustomerService) { }

  ngOnInit() {
   // this.customer = new Customer();

    this.accountNumber = this.route.snapshot.params['accountNumber'];
    
    this.customerService.getCustomer(this.accountNumber)
      .subscribe(data => {
        console.log(data)
        this.customer = data;
      }, error => console.log(error));
      this.router.navigate(['/details']);
  }
 
  
}
