import { Component, OnInit } from '@angular/core';
import { Customer } from '../Customer';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {

  sender:Customer;
  receiver:Customer;
  accountNumber:number;
  accountNumber1:number;
  amount:number;
  moneyTransferred=false;
  constructor(private route:ActivatedRoute,private http:HttpClient,
    private router:Router,private custservice:CustomerService) { }

  ngOnInit() {
    //this.sender=new Customer();
    //this.receiver=new Customer();
    this.accountNumber=this.route.snapshot.params['accountNumber'];
    this.accountNumber1=this.route.snapshot.params['accountNumber1'];
  }
  fundTransfer(accountNumber,accountNumber1,amount)
  {
    if(amount>0)
    {

    
    this.custservice.getCustomer(this.accountNumber).subscribe(
      data=>{
        console.log(data);
        this.sender=data;
      },
      error=>console.log(error)
    );
    this.custservice.fundTransfer(this.accountNumber,this.accountNumber1,amount,this.sender)
    .subscribe( 
      data=>{
      console.log(data),
      error=>console.log(error)
    }
      
      );
      alert("Amount Transfer!");
     
    if(this.moneyTransferred=true)
  {
    this.router.navigate(['ShowTransactionSummary',this.accountNumber]);
  }
}
else
{
  alert("Please, EnterVald Amount");
}
  }
  back()
  {
    this.router.navigate(['UserOperation',this.accountNumber]);
  }
}
